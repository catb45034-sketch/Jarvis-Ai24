package com.ultrapro.jarvis

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import kotlinx.coroutines.launch
import java.util.Locale

data class Message(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { tts?.language = Locale.ENGLISH }
        setContent {
            MaterialTheme {
                AppNav(tts)
            }
        }
    }
    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun AppNav(tts: TextToSpeech?) {
    val nav = rememberNavController()
    NavHost(navController = nav, startDestination = "chat") {
        composable("chat") { ChatScreen(tts, onOpenSettings = { nav.navigate("settings") }) }
        composable("settings") { SettingsScreen(onBack = { nav.popBackStack() }) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(tts: TextToSpeech?, onOpenSettings: () -> Unit) {
    var messages by remember { mutableStateOf(listOf<Message>()) }
    var input by remember { mutableStateOf(TextFieldValue("")) }
    val scope = rememberCoroutineScope()

    fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_tts")
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Jarvis UltraPro") },
                actions = {
                    TextButton(onClick = onOpenSettings) { Text("Settings") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            LazyColumn(Modifier.weight(1f).padding(8.dp)) {
                items(messages) { m ->
                    Surface(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(if (m.role=="user") "You" else "Jarvis", style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.height(4.dp))
                            Text(m.text)
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type your message...") }
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    val text = input.text
                    if (text.isNotBlank()) {
                        messages = messages + Message("user", text)
                        input = TextFieldValue("")
                        scope.launch {
                            try {
                                val reply = Api.chat(text)
                                messages = messages + Message("assistant", reply)
                                speak(reply)
                            } catch (e: Exception) {
                                val off = offlineReply(text)
                                messages = messages + Message("assistant", off)
                                speak(off)
                            }
                        }
                    }
                }) { Text("Send") }
            }
        }
    }
}

fun offlineReply(prompt: String): String {
    val p = prompt.lowercase()
    return when {
        listOf("hello","hi","namaste").any { p.contains(it) } -> "Namaste! Main Jarvis hoon — Ready to help."
        p.contains("name") -> "I'm Jarvis — UltraPro assistant."
        p.contains("help") -> "Ask me anything. Connect backend LLM for advanced AI."
        else -> "You said: \"" + prompt + "\". (Offline mode)."
    }
}
