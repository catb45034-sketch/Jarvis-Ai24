package com.ultrapro.jarvis

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.android.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class ChatReq(val message: String)
@Serializable
data class ChatResp(val reply: String)

object Api {
    // Android emulator to host: 10.0.2.2
    var baseUrl: String = "http://10.0.2.2:8000"

    private val client by lazy {
        HttpClient(Android) {
            install(ContentNegotiation) {
                json(Json { ignoreUnknownKeys = true })
            }
        }
    }

    suspend fun chat(message: String): String {
        val r: ChatResp = client.post("$baseUrl/chat") {
            setBody(ChatReq(message))
        }.body()
        return r.reply
    }
}
