rootProject.name = "AI Jarvis Beyond UltraPro"
include(":app")
