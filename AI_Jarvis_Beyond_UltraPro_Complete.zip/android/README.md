# Android App
- Compose chat UI, TTS, settings, Ktor client
- Default backend: http://10.0.2.2:8000
- Change in `Api.kt` if needed.

Generated: 2025-11-04T06:00:04.930238
