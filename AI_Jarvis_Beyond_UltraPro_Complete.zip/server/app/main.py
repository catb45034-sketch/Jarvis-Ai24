import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .schemas import ChatRequest, ChatResponse
from dotenv import load_dotenv
import httpx

load_dotenv()

app = FastAPI(title="Jarvis UltraPro Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY","")

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    user = req.message.strip()
    if not user:
        return ChatResponse(reply="Please say something 🙂")

    # If OpenAI key is present, try a lightweight call (placeholder)
    if OPENAI_API_KEY:
        # NOTE: Replace with your actual LLM endpoint. This is a safe placeholder.
        # We do NOT call external APIs here to keep the sample self-contained.
        cloud = f"[Cloud AI mock] You said: "{user}""
        return ChatResponse(reply=cloud)

    # Offline fallback rules
    p = user.lower()
    if any(g in p for g in ["hello","hi","namaste"]):
        return ChatResponse(reply="Namaste! Main Jarvis hoon — Ready to help.")
    if "name" in p:
        return ChatResponse(reply="I'm Jarvis — UltraPro assistant.")
    if "help" in p:
        return ChatResponse(reply="Ask me anything. Connect backend LLM for advanced AI.")
    return ChatResponse(reply=f"You said: "{user}". (Offline mode).")
