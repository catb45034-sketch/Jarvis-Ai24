#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/../server"
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
